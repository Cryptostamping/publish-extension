self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "03766700ea4f72fccbb8eaf56e2d27d1",
    "url": "/index.html"
  },
  {
    "revision": "cea1925cd269d3ce5147",
    "url": "/static/css/content.1c04e019.css"
  },
  {
    "revision": "90b27a819f1a9a7cf3b8",
    "url": "/static/css/main.d4d7127e.css"
  },
  {
    "revision": "82e63edee3f4130ca996",
    "url": "/static/js/background.js"
  },
  {
    "revision": "b98992ac9c4e0c5dc86c372616b213cb",
    "url": "/static/js/background.js.LICENSE.txt"
  },
  {
    "revision": "cea1925cd269d3ce5147",
    "url": "/static/js/content.js"
  },
  {
    "revision": "e85be89424d5e92d47c6bd673ac18817",
    "url": "/static/js/content.js.LICENSE.txt"
  },
  {
    "revision": "90b27a819f1a9a7cf3b8",
    "url": "/static/js/main.js"
  },
  {
    "revision": "e85be89424d5e92d47c6bd673ac18817",
    "url": "/static/js/main.js.LICENSE.txt"
  }
]);